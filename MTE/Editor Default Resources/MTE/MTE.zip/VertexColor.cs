﻿/*
 * Those cs file is already compiled into a dll here: Assets\Plugins\MTE\MTE_script.dll. So don't extract them into your project directory.
 * This is provided to allow you to modify it and compile it into MTE_script.dll. And then replace the orginal one.
 */
using UnityEngine;

[System.Serializable]
public class VertexColor : ScriptableObject
{
    //[HideInInspector]
    public Color[] colors = null;
}
